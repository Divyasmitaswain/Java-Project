package com.ecom.controller;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecom.model.Cart;
import com.ecom.model.Product;
import com.ecom.model.User;
import com.ecom.repository.UserRepository;
import com.ecom.service.CartService;
import com.ecom.service.ProductService;
import com.ecom.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserRepository userRepo; 

	@Autowired
	private CartService cartService;

	@Autowired
	private UserService userService;

	@Autowired
	private ProductService productService;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@ModelAttribute
	public void addCommnData(Principal p, Model m) {
		String email = p.getName();
		User user = userRepo.findByEmail(email);
		m.addAttribute("user", user);
	}

	@GetMapping("/")
	public String index() {
		return "index";
	}

	@GetMapping("/cart")
	public String cart(Model m, Principal p) {
		String email = p.getName();
		User user = userRepo.findByEmail(email);
		m.addAttribute("cartList", cartService.getCartByUser(user.getId()));
		m.addAttribute("productService", productService);

		List<Cart> cart = cartService.getCartByUser(user.getId());
		int billAmount = 0;
		for (Cart ca : cart) {

			Product pr = productService.getProductById(ca.getProductId());
			int totalAmount = pr.getPrice() * ca.getQuantity();
			billAmount = billAmount + totalAmount;
		}

		m.addAttribute("billAmount", billAmount);

		return "user/cart";
	}

	@GetMapping("/profile")
	public String profile() {
		return "user/profile";
	}

	@GetMapping("/password")
	public String password() {
		return "user/password";
	}

	@GetMapping("/setting")
	public String setting() {
		return "user/setting";
	}

	@GetMapping("/addCart/{userid}/{pid}")
	public String addCart(@PathVariable int userid, @PathVariable int pid, HttpSession session) {
		Cart c = new Cart();
		c.setUserId(userid);
		c.setProductId(pid);
		c.setQuantity(1);

		if (cartService.addCart(c) != null) {
			session.setAttribute("succMsg", "Watch Added to cart");

		} else {
			session.setAttribute("errorMsg", "Something wrong on server");
		}

		return "redirect:/viewProduct/" + pid;
	}

	@GetMapping("/cartIn/{pid}/{quantity}/{sign}/{id}/{userid}")
	public String cartQuantity(@PathVariable int pid, @PathVariable int quantity, @PathVariable String sign,
			@PathVariable int id, @PathVariable int userid, HttpSession session) {

		if ("add".equals(sign) && quantity >= 1) {
			quantity = quantity + 1;

		} else if ("neg".equals(sign) && quantity >= 1) {
			quantity = quantity - 1;

			if (quantity <= 0) {

				if (cartService.deleteCart(id)) {
					session.setAttribute("succMsg", "Item removed from cart");
					return "redirect:/user/cart";
				}

			}
		}

		Cart c = new Cart();
		c.setId(id);
		c.setProductId(pid);
		c.setQuantity(quantity);
		c.setUserId(userid);

		cartService.addCart(c);

		return "redirect:/user/cart";
	}

	@GetMapping("/ordSucc")
	public String orderSuccess() {
		return "user/order_success";
	}

	

	@PostMapping("/updateprofile")
	public String updateProfile(@ModelAttribute User user, HttpSession session) {

		User oldUser = userService.getUserById(user.getId());
		user.setRole(oldUser.getRole());
		user.setPassword(oldUser.getPassword());
		user.setEmail(oldUser.getEmail());

		if (userService.updateUser(user) != null) {
			session.setAttribute("succMsg", "Profile update sucessfully");
		} else {
			session.setAttribute("errorMsg", "something wrong on server ");
		}

		return "redirect:/user/profile";
	}

	@PostMapping("/changePsw")
	public String changePasw(Principal p, HttpSession session, @RequestParam("oldPassword") String oldPassword,
			@RequestParam("newPassword") String newPassword) {

		String email = p.getName();
		User currentUser = userRepo.findByEmail(email);

		if (passwordEncoder.matches(oldPassword, currentUser.getPassword())) {

			currentUser.setPassword(passwordEncoder.encode(newPassword));
			userRepo.save(currentUser);

			session.setAttribute("succMsg", "password change sucessfully");
		} else {
			session.setAttribute("errorMsg", "old password is incorrect");
		}

		return "redirect:/user/password";
	}

}
