package com.ecom.service;

import com.ecom.model.User;

public interface UserService {

	User createUser(User user);

	User getUserById(int uid);

	User updateUser(User user);

	User chechUserEmailAndMobNo(String email, String mobno);

}
