package com.ecom.controller;

import java.security.Principal;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecom.model.User;
import com.ecom.repository.UserRepository;
import com.ecom.service.CartService;
import com.ecom.service.ProductService;
import com.ecom.service.UserService;

@Controller
public class HomeController {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private UserService userService;

	@Autowired
	private ProductService productService;

	@Autowired
	private CartService cartService;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@ModelAttribute
	public void addCommnData(Principal p, Model m) {
		if (p != null) {
			String email = p.getName();
			User user = userRepo.findByEmail(email);
			m.addAttribute("user", user);
		}

	}

	@GetMapping("/")
	public String home(Model m) {
		m.addAttribute("cartService", cartService);
		return "index";
	}

	@GetMapping("/product")
	public String product(Model m) {
		m.addAttribute("product", productService.getAllProduct());
		return "product";
	}

	@GetMapping("/viewProduct/{id}")
	public String getProductById(Model m, @PathVariable int id) {
		m.addAttribute("cartService", cartService);
		m.addAttribute("p", productService.getProductById(id));
		return "view_product";
	}

	@GetMapping("/signin")
	public String login() {
		return "login";
	}

	@GetMapping("/register")
	public String register() {
		return "register";
	}

	@PostMapping("/addUser")
	public String registerUser(@ModelAttribute User user, HttpSession session) {

		if (userService.createUser(user) != null) {
			session.setAttribute("succMsg", "Register sucessfully");
		} else {
			session.setAttribute("errorMsg", "Register sucessfully");
		}

		return "redirect:/register";
	}

	@GetMapping("/loadforgotPassword")
	public String loadForgotPassword() {
		return "forgot_password";
	}

	@GetMapping("/loadresetPassword/{id}")
	public String loadResetPassword(@PathVariable int id, Model m) {
		m.addAttribute("uid", id);
		return "reset_password";
	}

	@PostMapping("/forgotPassword")
	public String forgotPassword(@RequestParam String email, @RequestParam String mobno, HttpSession session) {
		User u = userService.chechUserEmailAndMobNo(email, mobno);

		if (u != null) {
			return "redirect:/loadresetPassword/" + u.getId();

		} else {
			session.setAttribute("errorMsg", "invalid email & password");
			return "redirect:/loadforgotPassword";
		}

	}

	@PostMapping("/changePasswordx")
	public String changeNewPassword(@RequestParam String password, @RequestParam int uid, HttpSession session) {
		User user = userService.getUserById(uid);
		user.setPassword(passwordEncoder.encode(password));
		user.setId(uid);

		if (userService.updateUser(user) != null) {
			session.setAttribute("succMsg", "Password Change Sucessfully");
		} else {
			session.setAttribute("error", "Something wrong on server");
		}
		return "redirect:/loadforgotPassword";

	}

	@PostMapping("/search")
	public String bookSearch(@RequestParam String ch, Model m) {
		m.addAttribute("product", productService.getProductBySearch(ch, ch));

		return "/search";
	}

}
