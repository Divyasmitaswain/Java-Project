package com.ecom.service;

import java.util.List;

import com.ecom.model.Product;

public interface ProductService {

	public Product saveProduct(Product p);

	public List<Product> getAllProduct();

	public Product getProductById(int id);
	
	public List<Product> getProductBySearch(String ch,String ch2);

}
